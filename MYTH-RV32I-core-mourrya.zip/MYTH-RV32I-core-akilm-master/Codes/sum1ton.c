#include <stdio.h>
int main()
{	int I, sum=0,n=5;
	for(i=1;i<=n;++i)
{ sum+=1;
}
	printf(“Sum of numbers from 1 to %d is %d”,n,sum);
	return 0;
}
